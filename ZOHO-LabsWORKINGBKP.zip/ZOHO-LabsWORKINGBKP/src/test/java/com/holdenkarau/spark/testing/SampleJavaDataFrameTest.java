package com.holdenkarau.spark.testing;

import org.apache.hadoop.security.UserGroupInformation;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

public class SampleJavaDataFrameTest extends JavaDataFrameSuiteBase implements Serializable {
	@Test
	public void testEqualDataFrameWithItSelf() {
		List<BasicMagic> list = Arrays.asList(new BasicMagic("holden", 30), new BasicMagic("mahmoud", 23));

		DataFrame personsDataFrame = toDF(list);
		/*** rohit start ****/

		List<String> data = Arrays.asList("abc", "abc", "xyz");
		// Dataset<String> ds = context.createDataset(data, Encoders.STRING());

		// Dataset<Row> personsDataFrameDS =
		// personsDataFrame.as(RowEncoder$.MODULE$.apply(personsDataFrame.schema()));
//		DataFrame df = ctx.read().json(logFile);
//		Encoder<Person> encoder = Encoders.bean(Person.class);
//		Dataset<Person> ds = new Dataset<Person>(ctx, df.logicalPlan(), encoder);
		// Create a Dataset from a DataFrame
		// You can call df.as[SomeCaseClass] to convert the DataFrame to a Dataset.
		UserGroupInformation.setLoginUser(UserGroupInformation.createRemoteUser("LAPTOPTABLET"));
		SparkConf conf = new SparkConf().setAppName("uppercase").setMaster("local[*]");

		JavaSparkContext context = new JavaSparkContext(conf);
		// Dataset<String> ds = ((SQLContext) context).createDataset(data,
		// Encoders.STRING());
		SparkSession spark = SparkSession.builder().appName("Java Spark SQL data sources example")
				.config("spark.some.config.option", "some-value").getOrCreate();

		Dataset<String> ds = spark.createDataset(data, null);
		spark.stop();
		/*** rohit end ****/
		//assertDataFrameEquals(personsDataFrame, personsDataFrame);
		assertDataFrameEquals(ds,ds);
		List<BasicMagic> emptyList = Arrays.asList();
		DataFrame emptyDataFrame = toDF(emptyList);
		assertDataFrameEquals(emptyDataFrame, emptyDataFrame);
	}

	
	

	@Test
	public void testEqualDataFrames() {
		List<BasicMagic> magics1 = Arrays.asList(new BasicMagic("holden", 30), new BasicMagic("mahmoud", 23));

		List<BasicMagic> magics2 = Arrays.asList(new BasicMagic("holden", 30), new BasicMagic("mahmoud", 23));

		assertDataFrameEquals(toDF(magics1), toDF(magics2));
	}

	@Test(expected = java.lang.AssertionError.class)
	public void testNotEqualInteger() {
		List<BasicMagic> magics1 = Arrays.asList(new BasicMagic("mahmoud", 20), new BasicMagic("Holden", 25));

		List<BasicMagic> magics2 = Arrays.asList(new BasicMagic("mahmoud", 40), new BasicMagic("Holden", 25));

		assertDataFrameEquals(toDF(magics1), toDF(magics2));
	}

	@Test
	public void testApproximateEqual() {
		List<BasicMagic> magics1 = Arrays.asList(new BasicMagic("Holden", 10.0), new BasicMagic("Mahmoud", 9.9));

		List<BasicMagic> magics2 = Arrays.asList(new BasicMagic("Holden", 10.1), new BasicMagic("Mahmoud", 10.0));

		assertDataFrameApproximateEquals(toDF(magics1), toDF(magics2), 0.1);
	}

	@Test(expected = java.lang.AssertionError.class)
	public void testApproximateNotEqual() {
		List<BasicMagic> magics1 = Arrays.asList(new BasicMagic("Holden", 10.0), new BasicMagic("Mahmoud", 9.9));

		List<BasicMagic> magics2 = Arrays.asList(new BasicMagic("Holden", 10.2), new BasicMagic("Mahmoud", 10.0));

		assertDataFrameApproximateEquals(toDF(magics1), toDF(magics2), 0.1);
	}

	@Test
	public void testApproximateEqualRows() {
		List<BasicMagic> magics = Arrays.asList(new BasicMagic("Holden", 10.0), new BasicMagic("Mahmoud", 9.9));

		Row row1 = toDF(magics).collect()[0];
		Row row2 = toDF(magics).collect()[1];

		assertTrue(approxEquals(row1, row1, 0));
		assertFalse(approxEquals(row1, row2, 0));
	}

	public void testApproximateEqualTimestamp() {
		List<JavaMagicTime> magics1 = Arrays.asList(
				new JavaMagicTime("Holden", Timestamp.valueOf("2018-01-12 19:17:32")),
				new JavaMagicTime("Shakanti", Timestamp.valueOf("2018-01-12 19:17:32")));

		List<JavaMagicTime> magics2 = Arrays.asList(
				new JavaMagicTime("Holden", Timestamp.valueOf("2018-01-12 19:17:35")),
				new JavaMagicTime("Shakanti", Timestamp.valueOf("2018-01-12 19:18:40")));

		assertDataFrameApproximateEquals(timeDF(magics1), timeDF(magics2), 75000);
	}

	@Test(expected = java.lang.AssertionError.class)
	public void testApproximateNotEqualTimestamp() {
		List<JavaMagicTime> magics1 = Arrays.asList(
				new JavaMagicTime("Holden", Timestamp.valueOf("2018-01-12 19:17:32")),
				new JavaMagicTime("Shakanti", Timestamp.valueOf("2018-01-12 19:17:32")));

		List<JavaMagicTime> magics2 = Arrays.asList(
				new JavaMagicTime("Holden", Timestamp.valueOf("2018-01-12 19:17:35")),
				new JavaMagicTime("Shakanti", Timestamp.valueOf("2018-01-12 19:18:40")));

		assertDataFrameApproximateEquals(timeDF(magics1), timeDF(magics2), 59000);
	}

	@Test
	public void testApproximateEqualTimeRows() {
		List<JavaMagicTime> magics = Arrays.asList(
				new JavaMagicTime("Shakanti", Timestamp.valueOf("2018-01-12 20:49:32")),
				new JavaMagicTime("Shakanti", Timestamp.valueOf("2018-01-12 20:50:02")));

		DataFrame df = timeDF(magics);

		Row row1 = df.collect()[0];
		Row row2 = df.collect()[1];

		assertTrue(approxEquals(row1, row1, 0));
		assertTrue(approxEquals(row1, row2, 58000));
		assertFalse(approxEquals(row1, row2, 0));
	}

	private DataFrame timeDF(List<JavaMagicTime> list) {
		JavaRDD<JavaMagicTime> rdd = jsc().parallelize(list);
		return sqlContext().createDataFrame(rdd, JavaMagicTime.class);
	}

	private DataFrame toDF(List<BasicMagic> list) {
		JavaRDD<BasicMagic> rdd = jsc().parallelize(list);
		return sqlContext().createDataFrame(rdd, BasicMagic.class);
	}
}
